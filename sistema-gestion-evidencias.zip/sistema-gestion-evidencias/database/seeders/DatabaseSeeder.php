<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Usuario Docente
        User::create([
            'name' => 'Prof. Carlos Mendoza',
            'email' => 'docente@escuela.edu.mx',
            'password' => Hash::make('docente123'),
            'role' => 'docente',
            'is_active' => true,
        ]);

        // 15 Alumnos
        $alumnos = [
            ['name' => 'Sofía Ramírez Castro', 'email' => 'sofia.ramirez@alumnos.edu.mx'],
            ['name' => 'Mateo Fernández Gómez', 'email' => 'mateo.fernandez@alumnos.edu.mx'],
            ['name' => 'Valentina López Morales', 'email' => 'valentina.lopez@alumnos.edu.mx'],
            ['name' => 'Santiago Martínez Ruiz', 'email' => 'santiago.martinez@alumnos.edu.mx'],
            ['name' => 'Camila García Hernández', 'email' => 'camila.garcia@alumnos.edu.mx'],
            ['name' => 'Leonardo Torres Díaz', 'email' => 'leonardo.torres@alumnos.edu.mx'],
            ['name' => 'Isabella Vargas Mendoza', 'email' => 'isabella.vargas@alumnos.edu.mx'],
            ['name' => 'Sebastián Navarro Castillo', 'email' => 'sebastian.navarro@alumnos.edu.mx'],
            ['name' => 'Mariana Reyes Cruz', 'email' => 'mariana.reyes@alumnos.edu.mx'],
            ['name' => 'Diego Jiménez Flores', 'email' => 'diego.jimenez@alumnos.edu.mx'],
            ['name' => 'Lucía Gutiérrez Ortiz', 'email' => 'lucia.gutierrez@alumnos.edu.mx'],
            ['name' => 'Gabriel Romero Silva', 'email' => 'gabriel.romero@alumnos.edu.mx'],
            ['name' => 'Emma Aguilar Ramos', 'email' => 'emma.aguilar@alumnos.edu.mx'],
            ['name' => 'Alexander Delgado Vega', 'email' => 'alexander.delgado@alumnos.edu.mx'],
            ['name' => 'Ximena Peña Guerrero', 'email' => 'ximena.pena@alumnos.edu.mx'],
        ];

        foreach ($alumnos as $alumno) {
            User::create([
                'name' => $alumno['name'],
                'email' => $alumno['email'],
                'password' => Hash::make('alumno123'),
                'role' => 'alumno',
                'is_active' => true,
            ]);
        }
    }
}