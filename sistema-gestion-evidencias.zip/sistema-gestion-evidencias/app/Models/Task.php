<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Task extends Model
{
    protected $fillable = [
        'title', 'description', 'type', 'due_date', 'is_cancelled', 'created_by'
    ];

    protected $casts = [
        'due_date' => 'date',
        'is_cancelled' => 'boolean',
    ];

    public function submissions()
    {
        return $this->hasMany(Submission::class);
    }

    public function grades()
    {
        return $this->hasMany(Grade::class);
    }

    public function isExpired(): bool
    {
        // El plazo es hasta las 23:59:59 de la fecha asignada
        $deadline = Carbon::parse($this->due_date)->endOfDay();
        return Carbon::now()->greaterThan($deadline);
    }
}