<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function showLogin()
    {
        if (session()->has('user_id')) {
            return session('user_role') === 'docente' 
                ? redirect()->route('docente.dashboard') 
                : redirect()->route('alumno.dashboard');
        }
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $user = User::where('email', $request->email)->first();

        if ($user && Hash::check($request->password, $user->password)) {
            if (!$user->is_active) {
                return back()->withErrors(['email' => 'Tu cuenta ha sido desactivada por el docente.']);
            }

            session([
                'user_id' => $user->id,
                'user_name' => $user->name,
                'user_role' => $user->role,
            ]);

            return $user->role === 'docente' 
                ? redirect()->route('docente.dashboard') 
                : redirect()->route('alumno.dashboard');
        }

        return back()->withErrors(['email' => 'Las credenciales proporcionadas no son correctas.']);
    }

    public function logout()
    {
        session()->forget(['user_id', 'user_name', 'user_role']);
        session()->invalidate();
        return redirect()->route('login');
    }
}