<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\Submission;
use App\Models\Grade;
use App\Models\Notification;
use Carbon\Carbon;

class AlumnoController extends Controller
{
    public function dashboard()
    {
        $studentId = session('user_id');

        $tasks = Task::where('is_cancelled', false)
            ->orderBy('due_date', 'asc')
            ->get();

        $submissions = Submission::where('student_id', $studentId)->get()->keyBy('task_id');
        $grades = Grade::where('student_id', $studentId)
            ->where('status', 'publicado')
            ->get()
            ->keyBy('task_id');

        $notifications = Notification::where('user_id', $studentId)
            ->orderBy('created_at', 'desc')
            ->get();

        return view('alumno.dashboard', compact('tasks', 'submissions', 'grades', 'notifications'));
    }

    public function tareaDetalle($id)
    {
        $studentId = session('user_id');
        $task = Task::where('is_cancelled', false)->findOrFail($id);
        $submission = Submission::where('task_id', $id)->where('student_id', $studentId)->first();
        $grade = Grade::where('task_id', $id)->where('student_id', $studentId)->where('status', 'publicado')->first();

        return view('alumno.tarea_detalle', compact('task', 'submission', 'grade'));
    }

    public function uploadEvidencia(Request $request, $id)
    {
        $request->validate([
            'evidencia' => 'required|mimes:pdf|max:2048', // Un solo PDF <= 2MB (2048 KB)
        ], [
            'evidencia.required' => 'Debes adjuntar un archivo PDF.',
            'evidencia.mimes' => 'El archivo debe estar estrictamente en formato PDF.',
            'evidencia.max' => 'El archivo no puede exceder los 2MB de tamaño.',
        ]);

        $task = Task::findOrFail($id);

        if ($task->is_cancelled) {
            return back()->with('error', 'La tarea está cancelada, no se pueden enviar evidencias.');
        }

        if ($task->isExpired()) {
            return back()->with('error', 'La fecha límite de la tarea ha vencido.');
        }

        $path = $request->file('evidencia')->store('evidencias', 'public');

        Submission::updateOrCreate(
            ['task_id' => $task->id, 'student_id' => session('user_id')],
            ['file_path' => $path, 'submitted_at' => Carbon::now()]
        );

        return back()->with('success', 'Evidencia subida correctamente.');
    }

    public function markNotificationRead($id)
    {
        $notif = Notification::where('user_id', session('user_id'))->findOrFail($id);
        $notif->is_read = true;
        $notif->save();

        return back();
    }
}