<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Task;
use App\Models\Submission;
use App\Models\Grade;
use App\Models\Notification;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class DocenteController extends Controller
{
    public function dashboard()
    {
        $tasks = Task::with('submissions')->orderBy('created_at', 'desc')->get();
        $totalAlumnos = User::where('role', 'alumno')->where('is_active', true)->count();
        return view('docente.dashboard', compact('tasks', 'totalAlumnos'));
    }

    public function alumnos()
    {
        $alumnos = User::where('role', 'alumno')->get();
        return view('docente.alumnos', compact('alumnos'));
    }

    public function storeAlumnoIndividual(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'alumno',
            'is_active' => true,
        ]);

        return back()->with('success', 'Alumno creado correctamente.');
    }

    public function storeAlumnoMasivo(Request $request)
    {
        $request->validate([
            'bulk_data' => 'required|string'
        ]);

        $lines = explode("\n", str_replace("\r", "", $request->bulk_data));
        $created = 0;

        foreach ($lines as $line) {
            $data = array_map('trim', explode(',', $line));
            if (count($data) >= 3) {
                $name = $data[0];
                $email = $data[1];
                $pass = $data[2];

                if (!User::where('email', $email)->exists()) {
                    User::create([
                        'name' => $name,
                        'email' => $email,
                        'password' => Hash::make($pass),
                        'role' => 'alumno',
                        'is_active' => true,
                    ]);
                    $created++;
                }
            }
        }

        return back()->with('success', "Carga masiva completada. $created alumnos registrados.");
    }

    public function toggleAlumnoStatus($id)
    {
        $alumno = User::where('role', 'alumno')->findOrFail($id);
        $alumno->is_active = !$alumno->is_active;
        $alumno->save();

        return back()->with('success', 'Estado del alumno actualizado.');
    }

    public function updateAlumno(Request $request, $id)
    {
        $alumno = User::where('role', 'alumno')->findOrFail($id);
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,'.$alumno->id,
        ]);

        $alumno->name = $request->name;
        $alumno->email = $request->email;
        if ($request->filled('password')) {
            $alumno->password = Hash::make($request->password);
        }
        $alumno->save();

        return back()->with('success', 'Datos del alumno actualizados.');
    }

    public function createTareaView()
    {
        return view('docente.tarea_crear');
    }

    public function storeTarea(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'type' => 'required|in:tareas en casa,actividades en clase,exposiciones',
            'due_date' => 'required|date|after_or_equal:today',
        ]);

        $task = Task::create([
            'title' => $request->title,
            'description' => $request->description,
            'type' => $request->type,
            'due_date' => $request->due_date,
            'created_by' => session('user_id'),
        ]);

        // Notificar a todos los alumnos activos
        $alumnos = User::where('role', 'alumno')->where('is_active', true)->get();
        foreach ($alumnos as $alumno) {
            Notification::create([
                'user_id' => $alumno->id,
                'title' => 'Nueva Tarea Asignada',
                'message' => "Se ha asignado la tarea: {$task->title}. Fecha límite: {$task->due_date->format('d/m/Y')} a las 23:59.",
            ]);
        }

        return redirect()->route('docente.dashboard')->with('success', 'Tarea creada exitosamente.');
    }

    public function cancelTarea($id)
    {
        $task = Task::findOrFail($id);
        $task->is_cancelled = true;
        $task->save();

        // Notificar alumnos
        $alumnos = User::where('role', 'alumno')->where('is_active', true)->get();
        foreach ($alumnos as $alumno) {
            Notification::create([
                'user_id' => $alumno->id,
                'title' => 'Tarea Cancelada',
                'message' => "La tarea '{$task->title}' ha sido cancelada por el docente.",
            ]);
        }

        return back()->with('success', 'La tarea fue cancelada.');
    }

    public function evaluarTareaView($id)
    {
        $task = Task::findOrFail($id);

        if (!$task->isExpired()) {
            return redirect()->route('docente.dashboard')->with('error', 'Solo puedes evaluar la tarea una vez que haya pasado la fecha límite.');
        }

        $alumnos = User::where('role', 'alumno')->where('is_active', true)->get();
        $submissions = Submission::where('task_id', $id)->get()->keyBy('student_id');
        $grades = Grade::where('task_id', $id)->get()->keyBy('student_id');

        return view('docente.tarea_evaluar', compact('task', 'alumnos', 'submissions', 'grades'));
    }

    public function saveCalificaciones(Request $request, $id)
    {
        $task = Task::findOrFail($id);

        if (!$task->isExpired()) {
            return back()->with('error', 'Aún no ha expirado la fecha límite.');
        }

        $action = $request->input('action'); // 'borrador' o 'publicar'
        $status = ($action === 'publicar') ? 'publicado' : 'borrador';

        $scores = $request->input('scores', []);

        foreach ($scores as $studentId => $score) {
            if ($score !== null && $score !== '') {
                Grade::updateOrCreate(
                    ['task_id' => $task->id, 'student_id' => $studentId],
                    ['score' => min(10, max(0, floatval($score))), 'status' => $status]
                );

                if ($status === 'publicado') {
                    Notification::create([
                        'user_id' => $studentId,
                        'title' => 'Calificación Publicada',
                        'message' => "Se ha publicado tu calificación para la tarea '{$task->title}': {$score}/10.",
                    ]);
                }
            }
        }

        $msg = ($status === 'publicado') ? 'Calificaciones publicadas para los alumnos.' : 'Borrador de calificaciones guardado.';
        return redirect()->route('docente.dashboard')->with('success', $msg);
    }
}