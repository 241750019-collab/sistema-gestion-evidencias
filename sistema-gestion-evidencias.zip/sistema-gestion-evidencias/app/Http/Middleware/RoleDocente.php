<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class RoleDocente
{
    public function handle(Request $request, Closure $next)
    {
        if (session('user_role') !== 'docente') {
            return redirect()->route('login')->with('error', 'Acceso no autorizado para docentes.');
        }

        return $next($request);
    }
}