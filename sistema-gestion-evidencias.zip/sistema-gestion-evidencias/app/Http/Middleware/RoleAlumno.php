<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class RoleAlumno
{
    public function handle(Request $request, Closure $next)
    {
        if (session('user_role') !== 'alumno') {
            return redirect()->route('login')->with('error', 'Acceso exclusivo para alumnos.');
        }

        return $next($request);
    }
}