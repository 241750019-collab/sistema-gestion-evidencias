<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>@yield('title', 'Sistema de Gestión de Tareas')</title>
  @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body>
  @if(session()->has('user_id'))
    <div class="app-container">
      <!-- Sidebar / Barra de Navegación Lateral -->
      <aside class="sidebar">
        <div>
          <div class="sidebar-header">
            🎒 EduGestion
          </div>
          <ul class="sidebar-menu">
            @if(session('user_role') === 'docente')
              <li><a href="{{ route('docente.dashboard') }}" class="{{ request()->routeIs('docente.dashboard') ? 'active' : '' }}">📌 Inicio / Tareas</a></li>
              <li><a href="{{ route('docente.alumnos') }}" class="{{ request()->routeIs('docente.alumnos') ? 'active' : '' }}">👥 Gestión Alumnos</a></li>
              <li><a href="{{ route('docente.tarea.crear') }}" class="{{ request()->routeIs('docente.tarea.crear') ? 'active' : '' }}">➕ Crear Tarea</a></li>
            @else
              <li><a href="{{ route('alumno.dashboard') }}" class="{{ request()->routeIs('alumno.dashboard') ? 'active' : '' }}">📚 Mis Tareas y Notas</a></li>
            @endif
          </ul>
        </div>
        <div>
          <button id="theme-toggle" class="theme-toggle-btn">🌓 Cambiar Modo</button>
        </div>
      </aside>

      <div class="main-content-wrapper">
        <!-- Header superior -->
        <header class="header-bar">
          <div>
            <strong>Usuario:</strong> {{ session('user_name') }} <span class="badge badge-info">{{ ucfirst(session('user_role')) }}</span>
          </div>
          <div>
            <form action="{{ route('logout') }}" method="POST" style="display:inline;">
              @csrf
              <button type="submit" class="btn btn-sm btn-danger">Cerrar Sesión</button>
            </form>
          </div>
        </header>

        <!-- Contenido Principal -->
        <main class="content-body">
          @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
          @endif
          @if(session('error'))
            <div class="alert alert-error">{{ session('error') }}</div>
          @endif

          @yield('content')
        </main>

        <!-- Footer -->
        <footer class="footer-bar">
          &copy; {{ date('Y') }} Sistema de Gestión de Evidencias de Aula | Docente Único
        </footer>
      </div>
    </div>
  @else
    @yield('content')
  @endif
</body>
</html>