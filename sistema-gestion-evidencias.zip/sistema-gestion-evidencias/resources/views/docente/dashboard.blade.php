@extends('layouts.app')

@section('title', 'Panel Docente')

@section('content')
<div class="dashboard-card">
  <h2 class="card-title">📌 Control General de Tareas Asignadas</h2>
  <p>Total de alumnos activos registrados en el grupo: <strong>{{ $totalAlumnos }}</strong></p>

  <table class="custom-table">
    <thead>
      <tr>
        <th>Título</th>
        <th>Tipo</th>
        <th>Fecha Límite</th>
        <th>Estado Tarea</th>
        <th>Entregas</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      @forelse($tasks as $task)
        @php
          $submittedCount = $task->submissions->count();
          $pendingCount = $totalAlumnos - $submittedCount;
          $expired = $task->isExpired();
        @endphp
        <tr>
          <td><strong>{{ $task->title }}</strong></td>
          <td><span class="badge badge-info">{{ $task->type }}</span></td>
          <td>{{ $task->due_date->format('d/m/Y') }} 23:59</td>
          <td>
            @if($task->is_cancelled)
              <span class="badge badge-pending">CANCELADA</span>
            @elseif($expired)
              <span class="badge badge-pending">VENCIDA</span>
            @else
              <span class="badge badge-success">EN CURSO</span>
            @endif
          </td>
          <td>
            Entregaron: <strong>{{ $submittedCount }}</strong> / Pendientes: <strong>{{ max(0, $pendingCount) }}</strong>
          </td>
          <td>
            @if(!$task->is_cancelled)
              @if($expired)
                <a href="{{ route('docente.tarea.evaluar', $task->id) }}" class="btn btn-sm btn-primary">Evaluar / Ver Evidencias</a>
              @else
                <form action="{{ route('docente.tarea.cancelar', $task->id) }}" method="POST" style="display:inline;" onsubmit="return confirm('¿Seguro que deseas cancelar esta tarea?');">
                  @csrf
                  <button type="submit" class="btn btn-sm btn-danger">Cancelar Tarea</button>
                </form>
              @endif
            @else
              <em>Sin acciones</em>
            @endif
          </td>
        </tr>
      @empty
        <tr>
          <td colspan="6" style="text-align: center;">No se han asignado tareas todavía.</td>
        </tr>
      @endforelse
    </tbody>
  </table>
</div>
@endsection