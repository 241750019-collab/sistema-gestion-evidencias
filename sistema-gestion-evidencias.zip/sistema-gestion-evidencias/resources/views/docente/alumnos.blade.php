@extends('layouts.app')

@section('title', 'Gestión de Alumnos')

@section('content')
<div class="dashboard-card">
  <h2 class="card-title">➕ Registrar Alumno (Individual)</h2>
  <form action="{{ route('docente.alumnos.individual') }}" method="POST">
    @csrf
    <div style="display: flex; gap: 15px;">
      <div class="form-group" style="flex: 1;">
        <label>Nombre Completo:</label>
        <input type="text" name="name" class="form-control" required>
      </div>
      <div class="form-group" style="flex: 1;">
        <label>Correo Electrónico:</label>
        <input type="email" name="email" class="form-control" required>
      </div>
      <div class="form-group" style="flex: 1;">
        <label>Contraseña:</label>
        <input type="password" name="password" class="form-control" required>
      </div>
    </div>
    <button type="submit" class="btn btn-primary btn-sm" style="width: auto;">Guardar Alumno</button>
  </form>
</div>

<div class="dashboard-card">
  <h2 class="card-title">📥 Carga Masiva de Alumnos</h2>
  <p style="font-size: 0.9rem; margin-bottom: 10px;">Ingresa una línea por alumno con el formato: <code>Nombre, Correo, Contraseña</code></p>
  <form action="{{ route('docente.alumnos.masivo') }}" method="POST">
    @csrf
    <div class="form-group">
      <textarea name="bulk_data" class="form-control" rows="4" placeholder="Juan Perez, juan@alumnos.edu.mx, pass123&#10;Maria Lopez, maria@alumnos.edu.mx, pass123" required></textarea>
    </div>
    <button type="submit" class="btn btn-primary btn-sm" style="width: auto;">Procesar Carga Masiva</button>
  </form>
</div>

<div class="dashboard-card">
  <h2 class="card-title">👥 Lista de Alumnos</h2>
  <table class="custom-table">
    <thead>
      <tr>
        <th>Nombre</th>
        <th>Correo</th>
        <th>Estado</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      @foreach($alumnos as $alumno)
        <tr>
          <td>{{ $alumno->name }}</td>
          <td>{{ $alumno->email }}</td>
          <td>
            @if($alumno->is_active)
              <span class="badge badge-success">Activo</span>
            @else
              <span class="badge badge-pending">Desactivado</span>
            @endif
          </td>
          <td>
            <form action="{{ route('docente.alumnos.toggle', $alumno->id) }}" method="POST" style="display:inline;">
              @csrf
              <button type="submit" class="btn btn-sm {{ $alumno->is_active ? 'btn-danger' : 'btn-primary' }}">
                {{ $alumno->is_active ? 'Desactivar' : 'Activar' }}
              </button>
            </form>
          </td>
        </tr>
      @endforeach
    </tbody>
  </table>
</div>
@endsection