@extends('layouts.app')

@section('title', 'Evaluar Tarea')

@section('content')
<div class="dashboard-card">
  <h2 class="card-title">📝 Evaluación de Tarea: {{ $task->title }}</h2>
  <p><strong>Tipo:</strong> {{ $task->type }} | <strong>Fecha límite vencida:</strong> {{ $task->due_date->format('d/m/Y') }} 23:59</p>
</div>

<form action="{{ route('docente.tarea.guardarCalificaciones', $task->id) }}" method="POST">
  @csrf
  <div class="dashboard-card">
    <table class="custom-table">
      <thead>
        <tr>
          <th>Alumno</th>
          <th>Estado de Entrega</th>
          <th>Evidencia PDF</th>
          <th>Calificación (0 - 10)</th>
        </tr>
      </thead>
      <tbody>
        @foreach($alumnos as $alumno)
          @php
            $sub = $submissions->get($alumno->id);
            $grade = $grades->get($alumno->id);
          @endphp
          <tr>
            <td>{{ $alumno->name }}</td>
            <td>
              @if($sub)
                <span class="badge badge-success">Entregado</span><br>
                <small>{{ $sub->submitted_at }}</small>
              @else
                <span class="badge badge-pending">Sin Entrega</span>
              @endif
            </td>
            <td>
              @if($sub)
                <a href="{{ asset('storage/' . $sub->file_path) }}" target="_blank" class="btn btn-sm btn-secondary">🔍 Ver PDF</a>
              @else
                <em>N/A</em>
              @endif
            </td>
            <td>
              <input type="number" step="0.1" min="0" max="10" name="scores[{{ $alumno->id }}]" class="form-control" style="width: 100px;" value="{{ $grade ? $grade->score : '' }}">
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>

    <div style="margin-top: 20px; display: flex; gap: 15px; justify-content: flex-end;">
      <button type="submit" name="action" value="borrador" class="btn btn-secondary btn-sm">💾 Guardar Borrador</button>
      <button type="submit" name="action" value="publicar" class="btn btn-primary btn-sm">📢 Publicar Calificaciones</button>
    </div>
  </div>
</form>
@endsection