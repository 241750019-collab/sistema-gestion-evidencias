@extends('layouts.app')

@section('title', 'Crear Nueva Tarea')

@section('content')
<div class="dashboard-card" style="max-width: 650px; margin: 0 auto;">
  <h2 class="card-title">➕ Asignar Nueva Tarea</h2>
  <form action="{{ route('docente.tarea.store') }}" method="POST">
    @csrf
    <div class="form-group">
      <label>Título de la Tarea:</label>
      <input type="text" name="title" class="form-control" required>
    </div>

    <div class="form-group">
      <label>Descripción y Especificaciones:</label>
      <textarea name="description" class="form-control" rows="5" required></textarea>
    </div>

    <div class="form-group">
      <label>Tipo de Tarea:</label>
      <select name="type" class="form-control" required>
        <option value="tareas en casa">Tareas en Casa</option>
        <option value="actividades en clase">Actividades en Clase</option>
        <option value="exposiciones">Exposiciones</option>
      </select>
    </div>

    <div class="form-group">
      <label>Fecha de Entrega (Límite a las 23:59 hs de ese día):</label>
      <input type="date" name="due_date" class="form-control" min="{{ date('Y-m-d') }}" required>
    </div>

    <button type="submit" class="btn btn-primary">Asignar Tarea</button>
  </form>
</div>
@endsection