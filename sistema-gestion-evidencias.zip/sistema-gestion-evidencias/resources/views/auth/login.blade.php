@extends('layouts.app')

@section('title', 'Inicio de Sesión')

@section('content')
<div class="login-wrapper">
  <div class="login-card">
    <h2 class="login-title">inicio de sesion</h2>

    @if($errors->any())
      <div class="alert alert-error">
        {{ $errors->first() }}
      </div>
    @endif

    <form action="{{ route('login.post') }}" method="POST">
      @csrf
      <div class="form-group">
        <label for="email">Correo Electrónico:</label>
        <input type="email" name="email" id="email" class="form-control" required value="{{ old('email') }}">
      </div>

      <div class="form-group">
        <label for="password">Contraseña:</label>
        <input type="password" name="password" id="password" class="form-control" required>
      </div>

      <button type="submit" class="btn btn-primary" style="margin-top: 15px;">Ingresar</button>
    </form>
  </div>
</div>
@endsection