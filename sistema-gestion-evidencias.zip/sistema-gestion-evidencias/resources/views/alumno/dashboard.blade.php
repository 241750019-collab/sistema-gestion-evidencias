@extends('layouts.app')

@section('title', 'Mi Panel - Alumno')

@section('content')
@if($notifications->count() > 0)
  <div class="dashboard-card">
    <h3 class="card-title">🔔 Notificaciones</h3>
    <ul>
      @foreach($notifications as $notif)
        <li style="margin-bottom: 8px; {{ !$notif->is_read ? 'font-weight: bold;' : '' }}">
          {{ $notif->message }} <small>({{ $notif->created_at->diffForHumans() }})</small>
        </li>
      @endforeach
    </ul>
  </div>
@endif

<div class="dashboard-card">
  <h2 class="card-title">📚 Lista de Tareas Asignadas</h2>
  <table class="custom-table">
    <thead>
      <tr>
        <th>Tarea</th>
        <th>Tipo</th>
        <th>Fecha Límite</th>
        <th>Entrega</th>
        <th>Calificación</th>
        <th>Acción</th>
      </tr>
    </thead>
    <tbody>
      @forelse($tasks as $task)
        @php
          $sub = $submissions->get($task->id);
          $grade = $grades->get($task->id);
          $expired = $task->isExpired();
        @endphp
        <tr>
          <td><strong>{{ $task->title }}</strong></td>
          <td><span class="badge badge-info">{{ $task->type }}</span></td>
          <td>{{ $task->due_date->format('d/m/Y') }} 23:59</td>
          <td>
            @if($sub)
              <span class="badge badge-success">Entregado</span>
            @elseif($expired)
              <span class="badge badge-pending">No entregada</span>
            @else
              <span class="badge badge-pending">Pendiente</span>
            @endif
          </td>
          <td>
            @if($grade)
              <strong>{{ $grade->score }} / 10</strong>
            @else
              <em>Sin publicar / No evaluado</em>
            @endif
          </td>
          <td>
            <a href="{{ route('alumno.tarea.detalle', $task->id) }}" class="btn btn-sm btn-primary">Ver Detalle / Subir</a>
          </td>
        </tr>
      @empty
        <tr>
          <td colspan="6" style="text-align: center;">No tienes tareas pendientes por el momento.</td>
        </tr>
      @endforelse
    </tbody>
  </table>
</div>
@endsection