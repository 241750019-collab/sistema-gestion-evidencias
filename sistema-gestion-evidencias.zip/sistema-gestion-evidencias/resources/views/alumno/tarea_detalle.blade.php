@extends('layouts.app')

@section('title', 'Detalle de Tarea')

@section('content')
<div class="dashboard-card">
  <h2 class="card-title">{{ $task->title }}</h2>
  <p><span class="badge badge-info">{{ $task->type }}</span> | <strong>Fecha límite:</strong> {{ $task->due_date->format('d/m/Y') }} 23:59</p>

  <div style="background-color: var(--bg-main); border: 2px solid var(--border-color); padding: 15px; border-radius: 12px; margin: 15px 0;">
    <h4>Especificaciones:</h4>
    <p>{{ $task->description }}</p>
  </div>

  @if($grade)
    <div class="alert alert-success">
      🎓 <strong>Tu Calificación:</strong> {{ $grade->score }} / 10
    </div>
  @endif

  @if($submission)
    <div style="margin-bottom: 20px;">
      <p><strong>Evidencia enviada el:</strong> {{ $submission->submitted_at }}</p>
      <a href="{{ asset('storage/' . $submission->file_path) }}" target="_blank" class="btn btn-secondary btn-sm" style="width: auto;">📄 Ver mi PDF Subido</a>
    </div>
  @endif

  @if(!$task->isExpired() && !$task->is_cancelled)
    <hr style="margin: 20px 0; border: 1px dashed var(--border-color);">
    <h3>📤 Subir / Reemplazar Evidencia (PDF único, máx 2MB)</h3>
    <form action="{{ route('alumno.tarea.evidencia', $task->id) }}" method="POST" enctype="multipart/form-data" style="margin-top: 15px;">
      @csrf
      <div class="form-group">
        <input type="file" name="evidencia" id="evidencia-pdf-input" class="form-control" accept="application/pdf" required>
      </div>
      <button type="submit" class="btn btn-primary btn-sm" style="width: auto;">Enviar Evidencia</button>
    </form>
  @elseif($task->isExpired())
    <p style="color: var(--status-pending);"><em>El periodo para enviar o actualizar tu evidencia ha vencido.</em></p>
  @endif
</div>
@endsection