document.addEventListener('DOMContentLoaded', () => {
  // Configuración del Modo Oscuro / Claro
  const themeToggleBtn = document.getElementById('theme-toggle');
  const currentTheme = localStorage.getItem('theme') || 'light';

  if (currentTheme === 'dark') {
    document.documentElement.setAttribute('data-theme', 'dark');
  }

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      let theme = document.documentElement.getAttribute('data-theme');
      if (theme === 'dark') {
        document.documentElement.removeAttribute('data-theme');
        localStorage.setItem('theme', 'light');
      } else {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('theme', 'dark');
      }
    });
  }

  // Validación de archivos PDF <= 2MB
  const pdfInput = document.getElementById('evidencia-pdf-input');
  if (pdfInput) {
    pdfInput.addEventListener('change', function() {
      const file = this.files[0];
      if (file) {
        if (file.type !== 'application/pdf') {
          alert('Atención: Solo se permiten archivos en formato PDF.');
          this.value = '';
          return;
        }
        if (file.size > 2 * 1024 * 1024) {
          alert('Atención: El archivo no debe pesar más de 2MB.');
          this.value = '';
          return;
        }
      }
    });
  }
});