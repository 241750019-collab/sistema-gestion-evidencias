

<?php $__env->startSection('title', 'Gestión de Alumnos'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-card">
  <h2 class="card-title">➕ Registrar Alumno (Individual)</h2>
  <form action="<?php echo e(route('docente.alumnos.individual')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div style="display: flex; gap: 15px;">
      <div class="form-group" style="flex: 1;">
        <label>Nombre Completo:</label>
        <input type="text" name="name" class="form-control" required>
      </div>
      <div class="form-group" style="flex: 1;">
        <label>Correo Electrónico:</label>
        <input type="email" name="email" class="form-control" required>
      </div>
      <div class="form-group" style="flex: 1;">
        <label>Contraseña:</label>
        <input type="password" name="password" class="form-control" required>
      </div>
    </div>
    <button type="submit" class="btn btn-primary btn-sm" style="width: auto;">Guardar Alumno</button>
  </form>
</div>

<div class="dashboard-card">
  <h2 class="card-title">📥 Carga Masiva de Alumnos</h2>
  <p style="font-size: 0.9rem; margin-bottom: 10px;">Ingresa una línea por alumno con el formato: <code>Nombre, Correo, Contraseña</code></p>
  <form action="<?php echo e(route('docente.alumnos.masivo')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <textarea name="bulk_data" class="form-control" rows="4" placeholder="Juan Perez, juan@alumnos.edu.mx, pass123&#10;Maria Lopez, maria@alumnos.edu.mx, pass123" required></textarea>
    </div>
    <button type="submit" class="btn btn-primary btn-sm" style="width: auto;">Procesar Carga Masiva</button>
  </form>
</div>

<div class="dashboard-card">
  <h2 class="card-title">👥 Lista de Alumnos</h2>
  <table class="custom-table">
    <thead>
      <tr>
        <th>Nombre</th>
        <th>Correo</th>
        <th>Estado</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($alumno->name); ?></td>
          <td><?php echo e($alumno->email); ?></td>
          <td>
            <?php if($alumno->is_active): ?>
              <span class="badge badge-success">Activo</span>
            <?php else: ?>
              <span class="badge badge-pending">Desactivado</span>
            <?php endif; ?>
          </td>
          <td>
            <form action="<?php echo e(route('docente.alumnos.toggle', $alumno->id)); ?>" method="POST" style="display:inline;">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-sm <?php echo e($alumno->is_active ? 'btn-danger' : 'btn-primary'); ?>">
                <?php echo e($alumno->is_active ? 'Desactivar' : 'Activar'); ?>

              </button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PcLab7\sistema-gestion-evidencias\resources\views/docente/alumnos.blade.php ENDPATH**/ ?>