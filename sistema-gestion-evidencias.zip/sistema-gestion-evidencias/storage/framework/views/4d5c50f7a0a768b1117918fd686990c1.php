

<?php $__env->startSection('title', 'Mi Panel - Alumno'); ?>

<?php $__env->startSection('content'); ?>
<?php if($notifications->count() > 0): ?>
  <div class="dashboard-card">
    <h3 class="card-title">🔔 Notificaciones</h3>
    <ul>
      <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li style="margin-bottom: 8px; <?php echo e(!$notif->is_read ? 'font-weight: bold;' : ''); ?>">
          <?php echo e($notif->message); ?> <small>(<?php echo e($notif->created_at->diffForHumans()); ?>)</small>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<div class="dashboard-card">
  <h2 class="card-title">📚 Lista de Tareas Asignadas</h2>
  <table class="custom-table">
    <thead>
      <tr>
        <th>Tarea</th>
        <th>Tipo</th>
        <th>Fecha Límite</th>
        <th>Entrega</th>
        <th>Calificación</th>
        <th>Acción</th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
          $sub = $submissions->get($task->id);
          $grade = $grades->get($task->id);
          $expired = $task->isExpired();
        ?>
        <tr>
          <td><strong><?php echo e($task->title); ?></strong></td>
          <td><span class="badge badge-info"><?php echo e($task->type); ?></span></td>
          <td><?php echo e($task->due_date->format('d/m/Y')); ?> 23:59</td>
          <td>
            <?php if($sub): ?>
              <span class="badge badge-success">Entregado</span>
            <?php elseif($expired): ?>
              <span class="badge badge-pending">No entregada</span>
            <?php else: ?>
              <span class="badge badge-pending">Pendiente</span>
            <?php endif; ?>
          </td>
          <td>
            <?php if($grade): ?>
              <strong><?php echo e($grade->score); ?> / 10</strong>
            <?php else: ?>
              <em>Sin publicar / No evaluado</em>
            <?php endif; ?>
          </td>
          <td>
            <a href="<?php echo e(route('alumno.tarea.detalle', $task->id)); ?>" class="btn btn-sm btn-primary">Ver Detalle / Subir</a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="6" style="text-align: center;">No tienes tareas pendientes por el momento.</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PcLab7\sistema-gestion-evidencias\resources\views/alumno/dashboard.blade.php ENDPATH**/ ?>