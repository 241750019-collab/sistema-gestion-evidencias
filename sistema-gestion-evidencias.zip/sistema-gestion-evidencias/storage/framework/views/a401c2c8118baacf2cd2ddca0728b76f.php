

<?php $__env->startSection('title', 'Crear Nueva Tarea'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-card" style="max-width: 650px; margin: 0 auto;">
  <h2 class="card-title">➕ Asignar Nueva Tarea</h2>
  <form action="<?php echo e(route('docente.tarea.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label>Título de la Tarea:</label>
      <input type="text" name="title" class="form-control" required>
    </div>

    <div class="form-group">
      <label>Descripción y Especificaciones:</label>
      <textarea name="description" class="form-control" rows="5" required></textarea>
    </div>

    <div class="form-group">
      <label>Tipo de Tarea:</label>
      <select name="type" class="form-control" required>
        <option value="tareas en casa">Tareas en Casa</option>
        <option value="actividades en clase">Actividades en Clase</option>
        <option value="exposiciones">Exposiciones</option>
      </select>
    </div>

    <div class="form-group">
      <label>Fecha de Entrega (Límite a las 23:59 hs de ese día):</label>
      <input type="date" name="due_date" class="form-control" min="<?php echo e(date('Y-m-d')); ?>" required>
    </div>

    <button type="submit" class="btn btn-primary">Asignar Tarea</button>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PcLab7\sistema-gestion-evidencias\resources\views/docente/tarea_crear.blade.php ENDPATH**/ ?>