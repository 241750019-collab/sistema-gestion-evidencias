<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $__env->yieldContent('title', 'Sistema de Gestión de Tareas'); ?></title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
  <?php if(session()->has('user_id')): ?>
    <div class="app-container">
      <!-- Sidebar / Barra de Navegación Lateral -->
      <aside class="sidebar">
        <div>
          <div class="sidebar-header">
            🎒 EduGestion
          </div>
          <ul class="sidebar-menu">
            <?php if(session('user_role') === 'docente'): ?>
              <li><a href="<?php echo e(route('docente.dashboard')); ?>" class="<?php echo e(request()->routeIs('docente.dashboard') ? 'active' : ''); ?>">📌 Inicio / Tareas</a></li>
              <li><a href="<?php echo e(route('docente.alumnos')); ?>" class="<?php echo e(request()->routeIs('docente.alumnos') ? 'active' : ''); ?>">👥 Gestión Alumnos</a></li>
              <li><a href="<?php echo e(route('docente.tarea.crear')); ?>" class="<?php echo e(request()->routeIs('docente.tarea.crear') ? 'active' : ''); ?>">➕ Crear Tarea</a></li>
            <?php else: ?>
              <li><a href="<?php echo e(route('alumno.dashboard')); ?>" class="<?php echo e(request()->routeIs('alumno.dashboard') ? 'active' : ''); ?>">📚 Mis Tareas y Notas</a></li>
            <?php endif; ?>
          </ul>
        </div>
        <div>
          <button id="theme-toggle" class="theme-toggle-btn">🌓 Cambiar Modo</button>
        </div>
      </aside>

      <div class="main-content-wrapper">
        <!-- Header superior -->
        <header class="header-bar">
          <div>
            <strong>Usuario:</strong> <?php echo e(session('user_name')); ?> <span class="badge badge-info"><?php echo e(ucfirst(session('user_role'))); ?></span>
          </div>
          <div>
            <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline;">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-sm btn-danger">Cerrar Sesión</button>
            </form>
          </div>
        </header>

        <!-- Contenido Principal -->
        <main class="content-body">
          <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
          <?php endif; ?>
          <?php if(session('error')): ?>
            <div class="alert alert-error"><?php echo e(session('error')); ?></div>
          <?php endif; ?>

          <?php echo $__env->yieldContent('content'); ?>
        </main>

        <!-- Footer -->
        <footer class="footer-bar">
          &copy; <?php echo e(date('Y')); ?> Sistema de Gestión de Evidencias de Aula | Docente Único
        </footer>
      </div>
    </div>
  <?php else: ?>
    <?php echo $__env->yieldContent('content'); ?>
  <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\PcLab7\sistema-gestion-evidencias\resources\views/layouts/app.blade.php ENDPATH**/ ?>