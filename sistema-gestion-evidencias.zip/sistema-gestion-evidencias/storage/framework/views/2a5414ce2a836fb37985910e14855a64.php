

<?php $__env->startSection('title', 'Panel Docente'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-card">
  <h2 class="card-title">📌 Control General de Tareas Asignadas</h2>
  <p>Total de alumnos activos registrados en el grupo: <strong><?php echo e($totalAlumnos); ?></strong></p>

  <table class="custom-table">
    <thead>
      <tr>
        <th>Título</th>
        <th>Tipo</th>
        <th>Fecha Límite</th>
        <th>Estado Tarea</th>
        <th>Entregas</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
          $submittedCount = $task->submissions->count();
          $pendingCount = $totalAlumnos - $submittedCount;
          $expired = $task->isExpired();
        ?>
        <tr>
          <td><strong><?php echo e($task->title); ?></strong></td>
          <td><span class="badge badge-info"><?php echo e($task->type); ?></span></td>
          <td><?php echo e($task->due_date->format('d/m/Y')); ?> 23:59</td>
          <td>
            <?php if($task->is_cancelled): ?>
              <span class="badge badge-pending">CANCELADA</span>
            <?php elseif($expired): ?>
              <span class="badge badge-pending">VENCIDA</span>
            <?php else: ?>
              <span class="badge badge-success">EN CURSO</span>
            <?php endif; ?>
          </td>
          <td>
            Entregaron: <strong><?php echo e($submittedCount); ?></strong> / Pendientes: <strong><?php echo e(max(0, $pendingCount)); ?></strong>
          </td>
          <td>
            <?php if(!$task->is_cancelled): ?>
              <?php if($expired): ?>
                <a href="<?php echo e(route('docente.tarea.evaluar', $task->id)); ?>" class="btn btn-sm btn-primary">Evaluar / Ver Evidencias</a>
              <?php else: ?>
                <form action="<?php echo e(route('docente.tarea.cancelar', $task->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('¿Seguro que deseas cancelar esta tarea?');">
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-sm btn-danger">Cancelar Tarea</button>
                </form>
              <?php endif; ?>
            <?php else: ?>
              <em>Sin acciones</em>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="6" style="text-align: center;">No se han asignado tareas todavía.</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PcLab7\sistema-gestion-evidencias\resources\views/docente/dashboard.blade.php ENDPATH**/ ?>