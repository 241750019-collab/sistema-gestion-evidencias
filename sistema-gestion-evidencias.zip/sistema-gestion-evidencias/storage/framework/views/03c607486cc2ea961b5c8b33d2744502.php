

<?php $__env->startSection('title', 'Detalle de Tarea'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-card">
  <h2 class="card-title"><?php echo e($task->title); ?></h2>
  <p><span class="badge badge-info"><?php echo e($task->type); ?></span> | <strong>Fecha límite:</strong> <?php echo e($task->due_date->format('d/m/Y')); ?> 23:59</p>

  <div style="background-color: var(--bg-main); border: 2px solid var(--border-color); padding: 15px; border-radius: 12px; margin: 15px 0;">
    <h4>Especificaciones:</h4>
    <p><?php echo e($task->description); ?></p>
  </div>

  <?php if($grade): ?>
    <div class="alert alert-success">
      🎓 <strong>Tu Calificación:</strong> <?php echo e($grade->score); ?> / 10
    </div>
  <?php endif; ?>

  <?php if($submission): ?>
    <div style="margin-bottom: 20px;">
      <p><strong>Evidencia enviada el:</strong> <?php echo e($submission->submitted_at); ?></p>
      <a href="<?php echo e(asset('storage/' . $submission->file_path)); ?>" target="_blank" class="btn btn-secondary btn-sm" style="width: auto;">📄 Ver mi PDF Subido</a>
    </div>
  <?php endif; ?>

  <?php if(!$task->isExpired() && !$task->is_cancelled): ?>
    <hr style="margin: 20px 0; border: 1px dashed var(--border-color);">
    <h3>📤 Subir / Reemplazar Evidencia (PDF único, máx 2MB)</h3>
    <form action="<?php echo e(route('alumno.tarea.evidencia', $task->id)); ?>" method="POST" enctype="multipart/form-data" style="margin-top: 15px;">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <input type="file" name="evidencia" id="evidencia-pdf-input" class="form-control" accept="application/pdf" required>
      </div>
      <button type="submit" class="btn btn-primary btn-sm" style="width: auto;">Enviar Evidencia</button>
    </form>
  <?php elseif($task->isExpired()): ?>
    <p style="color: var(--status-pending);"><em>El periodo para enviar o actualizar tu evidencia ha vencido.</em></p>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PcLab7\sistema-gestion-evidencias\resources\views/alumno/tarea_detalle.blade.php ENDPATH**/ ?>