

<?php $__env->startSection('title', 'Inicio de Sesión'); ?>

<?php $__env->startSection('content'); ?>
<div class="login-wrapper">
  <div class="login-card">
    <h2 class="login-title">inicio de sesion</h2>

    <?php if($errors->any()): ?>
      <div class="alert alert-error">
        <?php echo e($errors->first()); ?>

      </div>
    <?php endif; ?>

    <form action="<?php echo e(route('login.post')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="email">Correo Electrónico:</label>
        <input type="email" name="email" id="email" class="form-control" required value="<?php echo e(old('email')); ?>">
      </div>

      <div class="form-group">
        <label for="password">Contraseña:</label>
        <input type="password" name="password" id="password" class="form-control" required>
      </div>

      <button type="submit" class="btn btn-primary" style="margin-top: 15px;">Ingresar</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PcLab7\sistema-gestion-evidencias\resources\views/auth/login.blade.php ENDPATH**/ ?>