<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DocenteController;
use App\Http\Controllers\AlumnoController;
use App\Http\Middleware\AuthCheck;
use App\Http\Middleware\RoleDocente;
use App\Http\Middleware\RoleAlumno;

// Rutas de Autenticación
Route::get('/', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Rutas con autenticación
Route::middleware([AuthCheck::class])->group(function () {

    // Rutas para Docente
    Route::middleware([RoleDocente::class])->prefix('docente')->group(function () {
        Route::get('/dashboard', [DocenteController::class, 'dashboard'])->name('docente.dashboard');
        
        // Gestión de Alumnos
        Route::get('/alumnos', [DocenteController::class, 'alumnos'])->name('docente.alumnos');
        Route::post('/alumnos/individual', [DocenteController::class, 'storeAlumnoIndividual'])->name('docente.alumnos.individual');
        Route::post('/alumnos/masivo', [DocenteController::class, 'storeAlumnoMasivo'])->name('docente.alumnos.masivo');
        Route::post('/alumnos/toggle/{id}', [DocenteController::class, 'toggleAlumnoStatus'])->name('docente.alumnos.toggle');
        Route::put('/alumnos/update/{id}', [DocenteController::class, 'updateAlumno'])->name('docente.alumnos.update');

        // Gestión de Tareas
        Route::get('/tarea/crear', [DocenteController::class, 'createTareaView'])->name('docente.tarea.crear');
        Route::post('/tarea/store', [DocenteController::class, 'storeTarea'])->name('docente.tarea.store');
        Route::post('/tarea/cancelar/{id}', [DocenteController::class, 'cancelTarea'])->name('docente.tarea.cancelar');

        // Evaluación
        Route::get('/tarea/evaluar/{id}', [DocenteController::class, 'evaluarTareaView'])->name('docente.tarea.evaluar');
        Route::post('/tarea/evaluar/{id}', [DocenteController::class, 'saveCalificaciones'])->name('docente.tarea.guardarCalificaciones');
    });

    // Rutas para Alumnos
    Route::middleware([RoleAlumno::class])->prefix('alumno')->group(function () {
        Route::get('/dashboard', [AlumnoController::class, 'dashboard'])->name('alumno.dashboard');
        Route::get('/tarea/{id}', [AlumnoController::class, 'tareaDetalle'])->name('alumno.tarea.detalle');
        Route::post('/tarea/{id}/evidencia', [AlumnoController::class, 'uploadEvidencia'])->name('alumno.tarea.evidencia');
        Route::post('/notificacion/leer/{id}', [AlumnoController::class, 'markNotificationRead'])->name('alumno.notificacion.leer');
    });

});